# Security Policy

## Supported Versions

As `liftinstall` is a template for your project, no specific versioning is
provided at this time, though a rough version is given in the Cargo file. 

Only the latest version from this file will be supported.

## Reporting a Vulnerability

For any specific security concerns/vulnerabilities, please email me directly
at security *at* jselby.net.
