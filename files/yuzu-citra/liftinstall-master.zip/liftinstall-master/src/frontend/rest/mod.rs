//! frontend/rest/mod.rs
//!
//! Contains the main web server used within the application.

mod assets;
pub mod server;
pub mod services;
